package StepDefination;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.HashMap;
import java.util.Map;

public class AddcustomersStepdefs {
    @Given("^Manager lands on XYZ bank home page$")
    public void managerLandsOnXYZBankHomePage() {
        ChromeOptions options = new ChromeOptions();
        Map<String, Object> prefs = new HashMap<String, Object>();
        Map<String, Object> profile = new HashMap<String, Object>();
        Map<String, Integer> contentSettings = new HashMap<String, Integer>();
        //0 - Default, 1 - Allow, 2 - Block
        contentSettings.put("notifications", 2);
        contentSettings.put("geolocation", 2);
        profile.put("managed_default_content_settings", contentSettings);
        prefs.put("profile", profile);
        options.setExperimentalOption("prefs", prefs);
        options.addArguments("--remote-allow-origins=*");

//        options.addArguments("--no-sandbox");
//        options.addArguments("--disable-dev-shm-usage");
//        options.addArguments("--headless");
        WebDriverManager.chromedriver().setup();
        ChromeDriver driver;
        driver = new ChromeDriver(options);

        driver.get("https://globalsqa.com/angularJs-protractor/BankingProject/#/manager");
        driver.manage().window().maximize();
//        Thread.sleep(2000); // kotokkhn dhore rakbe seta bujhaise .. mane delay time r ki
    }

    @When("manager clicks on bank manager login option")
    public void managerClicksOnBankManagerLoginOption() {

        
    }

    @And("clicks on add customer tab")
    public void clicksOnAddCustomerTab() {
        
    }

    @And("sends customer {string} and {string} and {string}")
    public void sendsCustomerFirstNameAndLastNameAndPostCode() {
        
    }

    @And("clicks on add customer button")
    public void clicksOnAddCustomerButton() {
        
    }

    @Then("go to the next page")
    public void goToTheNextPage() {
    }
}
